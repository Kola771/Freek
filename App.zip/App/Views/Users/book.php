

<?php


require "../App/Controllers/Control.php";
    require "header.php";
?>

<main>
<?php
echo $b;

?>
<form action="?book/index" method="post">
    <input type="text" name = "ok">
    <button type="submit">Validate</button>
</form>
</main>

<?php
    require "footer.php";
?>