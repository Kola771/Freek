
<?php
    require "header.php";
    require "../App/Controllers/register.inc.php";
?>
<main>
        <form class="form flex" action="?receive/register" method="post">
            <input type="text" placeholder="Firstname" name="firstname" value ="<?= isset($_POST["firstname"]) ? $_POST["firstname"] : "" ?>" required>
            <input type="text" placeholder="Lastname" name="lastname" value ="<?= isset($_POST["lastname"]) ? $_POST["lastname"] : "" ?>" required>
            <input type="email" placeholder="Email" name="email" value ="<?= isset($_POST["email"]) ? $_POST["email"] : "" ?>" required>
            <input type="text" placeholder="Username" name="username" value ="<?= isset($_POST["username"]) ? $_POST["username"] : "" ?>" required>
            <div class="flex password">
                <input type="password" maxlength="14" placeholder="Password" name="password" value ="<?= isset($_POST["password"]) ? $_POST["password"] : "" ?>" required>
                <input type="password" maxlength="14" placeholder="Confirm password" name="confirm_password" value ="<?= isset($_POST["confirm_password"]) ? $_POST["confirm_password"] : "" ?>" required>
            </div>
            <input type="text" placeholder="Entrez un mot clé" name="word_key" value ="<?= isset($_POST["word_key"]) ? $_POST["word_key"] : "" ?>" required>
            <button class="white" type="submit">Valider</button>
            <p>Vous avez pas un compte ? <a href="?receive/login">Connectez-vous</a></p>
            <div class="style"></div>
        </form>
</main>

<?php
    require "footer.php";
?>