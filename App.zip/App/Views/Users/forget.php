


<?php
    require "header.php";
?>
<main>
        <form class="form flex" action="#" method="post">
            <input type="email" placeholder="Email">
            <input type="text" placeholder="Entrez votre mot clé">
            <button class="white" type="submit">Valider</button>
            <div class="info flex">
                <a href="?receive/login">Retour</a>
            </div>
            <div class="style"></div>
        </form>
</main>

<?php
    require "footer.php";
?>