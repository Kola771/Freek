
<?php
    require "header.php";
?>
<main>
        <form class="form flex" action="#" method="post">
            <input type="email" placeholder="Email" required>
            <input type="password" placeholder="Password" required>
            <div class="remember">
                <input type="checkbox" name="" id="" checked>Se rappeler de moi
            </div>
            <button class="white" type="submit">Valider</button>
            <div class="info flex">
                <a href="?receive/forget">Vous avez oublié votre mot de passe ?</a>
                <p>Vous n'avez pas un compte ? <a href="?receive/register">Inscrivez-vous</a></p>
            </div>
            <div class="style"></div>
        </form>
</main>

<?php
    require "footer.php";
?>