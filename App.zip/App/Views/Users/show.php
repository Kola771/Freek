<?php
    require "header.php";
?>

<main>

</main>

<?php
    require "footer.php";
?>