<?php
$url = $_POST["ok"];
echo $url;
if ($url == "td") {
    require "home.php";
}
?>