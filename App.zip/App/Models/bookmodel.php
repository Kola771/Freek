

<?php

class bookmodel {

    public function shows($id) {
        return $this->id = $id + 1;
    }
}

?>