

<?php
    if($_SERVER["REQUEST_METHOD"] === "POST") {
        $firstname = $_POST["firstname"];
        echo "Votre prénom est : $firstname";
        $lastname = $_POST["lastname"];

        $_SESSION["firstname"] = $firstname;
        // $_SESSION["role"] = "admin";

        header("Location: ?receive/home");
    }
?>