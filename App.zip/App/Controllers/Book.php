

<?php

class Book {
    public function showBook() {
        require "../App/Views/Users/book.php";
    }
}

?>