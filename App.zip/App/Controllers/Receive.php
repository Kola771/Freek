

<?php

class Receive {
    public function home() {
        require "../App/Views/Users/home.php";
    }
    
    public function dashbord() {
        require "../App/Views/Admin/index.php";
    }

    public function profil() {
       require "../App/Views/Users/profil.php";
    }
    
    public function register() {
        require "../App/Views/Users/register.php";
    }
    
    public function logout() {
        session_start();
        session_unset();
        session_destroy();
        header("location: ?receive/login");
    }
    
    public function login() {
        require "../App/Views/Users/login.php";
    }

    public function forget() {
        require "../App/Views/Users/forget.php";
    }
}

?>