
<?php
require "../Core/Router.php";
$url = $_SERVER["QUERY_STRING"];

$router = new Router();
$router->add('', ['controller' => 'Receive', 'action' => 'home']);
$router->add("{controller}/{action}");
$router->add("admin/{controller}/{action}");
$router->add("{controller}/{id:\d+}/{action}");

// var_dump($router->match($url));
$router->dispatch($url);
// var_dump($router->getmatch($url));

// echo $router->getId();

?>
