

<footer>
    <div class="flex">
        <section>
            <h3>Actualités</h3>
        </section>
        <section>
            <h3>Oeuvres</h3>
        </section>
        <section>
            <h3>Inédits</h3>
        </section>
    </div>
    <p>&copy;Copyright 2022. Fait par Koladé M. ABOUDOU.</p>
</footer>
</body>
</html>