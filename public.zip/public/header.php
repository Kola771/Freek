
<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/b48549a02e.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="ressources/css/styles.css">
    <link rel="icon" type="image/x-icon">
    <title>Freek</title>
</head>
<body>
    <header>
        <div class="header flex white">
            <h1 class="margin0">Fre<span class="orange">ek</span> </h1>
            <nav>
                <ul class="topul flex list">
                    <li><a href="?receive/home">Home</a></li>
                    <?php if(isset($_SESSION["role"]) && $_SESSION["role"] === "admin"): ?>
                        <li><a href="?receive/dashbord">Dashbord</a></li>
                        <li><a href="?receive/profil"><i class="fa fa-account"></i>Profil</a></li>
                        <li><a href="?receive/logout">Deconnexion</a></li>
                    <?php elseif(isset($_SESSION["firstname"])): ?>
                        <li><a href="?receive/profil"><i class="fa fa-account"></i><?= $_SESSION["firstname"] ?></a></li>
                        <li><a href="?receive/logout">Deconnexion</a></li>
                    <?php else: ?>
                        <li><a href="?receive/login">Login</a></li>
                    <?php endif; ?>
                    
                </ul>
            </nav>
        </div>
    </header>